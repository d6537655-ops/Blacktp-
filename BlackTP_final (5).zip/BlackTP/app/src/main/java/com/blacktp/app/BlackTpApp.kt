package com.blacktp.app

import android.app.Application
import com.blacktp.app.player.PlayerController
import com.blacktp.app.theme.ThemeManager

class BlackTpApp : Application() {
    override fun onCreate() { super.onCreate(); ThemeManager.init(this); PlayerController.init(this) }
}
