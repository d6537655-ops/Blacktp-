package com.blacktp.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blacktp.app.theme.ThemeManager
import com.blacktp.app.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            val theme by ThemeManager.theme.collectAsState()
            val skin = remember(theme) { ThemeManager.skin(theme) }
            val scheme = if (skin.bg.luminance() > 0.5f)
                lightColorScheme(primary = skin.accent, background = skin.bg, surface = skin.bg, onSurface = skin.text, onBackground = skin.text)
            else darkColorScheme(primary = skin.accent, background = skin.bg, surface = skin.bg, onSurface = skin.text, onBackground = skin.text)
            CompositionLocalProvider(LocalSkin provides skin) {
                MaterialTheme(colorScheme = scheme) {
                    CompositionLocalProvider(LocalContentColor provides skin.text) {
                        var screen by remember { mutableIntStateOf(0) }
                        Box(Modifier.fillMaxSize()) {
                            Wallpaper(skin, if (screen == 0) skin.wpPlayer else skin.wpLib, Modifier.fillMaxSize())
                            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                                Box(Modifier.weight(1f)) {
                                    when (screen) {
                                        0 -> PlayerScreen(); 1 -> LibraryScreen(); 2 -> QueueScreen()
                                        3 -> CustomizeScreen(); else -> SettingsScreen()
                                    }
                                }
                                Row(Modifier.fillMaxWidth().background(skin.panel).navigationBarsPadding(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    listOf("PLAYER", "LIBRARY", "QUEUE", "CUSTOMIZE", "SETTINGS").forEachIndexed { i, n ->
                                        TextButton({ screen = i }, Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 2.dp)) {
                                            Text(n, fontFamily = skin.font, fontSize = 10.sp, maxLines = 1,
                                                color = if (screen == i) skin.accent else skin.textDim)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
