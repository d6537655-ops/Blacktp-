package com.blacktp.app.audio

import android.media.audiofx.Equalizer

/** System equalizer attached to the engine's fixed audio session. Levels are in millibels. */
object Eq {
    private var eq: Equalizer? = null
    var centersHz: List<Int> = emptyList(); private set
    var minLevel = -1500; private set
    var maxLevel = 1500; private set

    fun attach(session: Int) {
        try {
            eq?.release()
            val e = Equalizer(0, session); eq = e
            minLevel = e.bandLevelRange[0].toInt(); maxLevel = e.bandLevelRange[1].toInt()
            centersHz = (0 until e.numberOfBands).map { e.getCenterFreq(it.toShort()) / 1000 }
        } catch (_: Exception) { eq = null; centersHz = emptyList() }
    }

    fun apply(on: Boolean, levels: List<Int>) {
        val e = eq ?: return
        try {
            e.enabled = on
            levels.forEachIndexed { i, l -> if (i < centersHz.size) e.setBandLevel(i.toShort(), l.coerceIn(minLevel, maxLevel).toShort()) }
        } catch (_: Exception) {}
    }

    fun parse(s: String?): List<Int> = s?.split(",")?.mapNotNull { it.toIntOrNull() } ?: emptyList()
    fun levelsOrFlat(s: String?): List<Int> = parse(s).let { l -> List(centersHz.size) { l.getOrElse(it) { 0 } } }
}
