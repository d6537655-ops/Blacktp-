package com.blacktp.app.audio

import android.content.Context
import android.media.*
import android.net.Uri
import kotlin.math.abs

/** Decoded PCM (interleaved stereo, 16-bit) held in memory so it can be read in ANY direction. */
class PcmBuffer(val data: ShortArray, val frames: Int, val sampleRate: Int)

object PcmDecoder {
    fun decode(ctx: Context, uri: Uri): PcmBuffer {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        val idx = (0 until ex.trackCount).first {
            ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")
        }
        ex.selectTrack(idx)
        val fmt = ex.getTrackFormat(idx)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0); codec.start()
        var out = ShortArray(1 shl 20); var n = 0
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val info = MediaCodec.BufferInfo()
        var inDone = false; var outDone = false
        while (!outDone) {
            if (!inDone) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val sz = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                    if (sz < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                    else { codec.queueInputBuffer(i, 0, sz, ex.sampleTime, 0); ex.advance() }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10_000)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val f = codec.outputFormat
                ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT); sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else if (o >= 0) {
                val sb = codec.getOutputBuffer(o)!!.order(java.nio.ByteOrder.nativeOrder()).asShortBuffer()
                val cnt = info.size / 2
                val add = if (ch == 1) cnt * 2 else cnt
                if (n + add > out.size) out = out.copyOf(maxOf(out.size * 2, n + add))
                if (ch == 1) { for (k in 0 until cnt) { val s = sb.get(); out[n++] = s; out[n++] = s } }
                else { sb.get(out, n, cnt); n += cnt }   // >2 channels not handled in this stage
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            }
        }
        codec.stop(); codec.release(); ex.release()
        return PcmBuffer(out, n / 2, sr)
    }
}

/**
 * Real scratch engine: float read-head over PCM, signed playback rate (negative = true reverse),
 * linear interpolation, own audio thread (UI never blocks).
 */
class ScratchEngine {
    @Volatile var pcm: PcmBuffer? = null
    @Volatile var playing = false
    @Volatile var vinylMode = false
    @Volatile var touching = false
    @Volatile var wheelRate = 0f        // set by the wheel while finger is down
    @Volatile var inertia = 0.5f        // 0..1, higher = slower return to normal speed
    @Volatile var onEnded: (() -> Unit)? = null
    @Volatile var currentRate = 0f
    @Volatile var gain = 1f
    @Volatile var sessionId = 0
    @Volatile private var pos = 0.0
    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null

    val positionMs: Long get() = pcm?.let { (pos / it.sampleRate * 1000).toLong() } ?: 0
    val durationMs: Long get() = pcm?.let { it.frames * 1000L / it.sampleRate } ?: 0
    fun seekMs(ms: Long) { pcm?.let { pos = (ms * it.sampleRate / 1000.0).coerceIn(0.0, it.frames - 2.0) } }

    fun load(p: PcmBuffer) { stop(); pcm = p; pos = 0.0; start(p.sampleRate) }

    private fun start(sr: Int) {
        val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sr)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(min).setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .apply { if (sessionId != 0) setSessionId(sessionId) }.build()
        track = t; running = true; t.play()
        thread = Thread({ renderLoop(t) }, "scratch-audio").apply {
            priority = Thread.MAX_PRIORITY; start()
        }
    }

    private fun renderLoop(t: AudioTrack) {
        val frames = 256
        val buf = ShortArray(frames * 2)
        var rate = 0f
        while (running) {
            val p = pcm ?: break
            val d = p.data; val last = p.frames - 2
            val target = when {
                vinylMode && touching -> wheelRate
                playing -> 1f
                else -> 0f
            }
            // finger = tight tracking; released = inertia glide back to target
            val k = if (vinylMode && touching) 0.35f else 0.002f + (1f - inertia) * 0.05f
            val g = gain
            for (i in 0 until frames) {
                rate += (target - rate) * k
                pos += rate
                if (pos < 0.0) { pos = 0.0; rate = 0f }
                if (pos > last) { pos = last.toDouble(); rate = 0f; if (playing) { playing = false; onEnded?.invoke() } }
                val ip = pos.toInt(); val fr = (pos - ip).toFloat()
                val a = ip * 2
                buf[i * 2]     = ((d[a] + (d[a + 2] - d[a]) * fr) * g).toInt().toShort()
                buf[i * 2 + 1] = ((d[a + 1] + (d[a + 3] - d[a + 1]) * fr) * g).toInt().toShort()
            }
            currentRate = rate
            t.write(buf, 0, buf.size)   // blocking = natural pacing, on audio thread only
        }
    }

    fun stop() {
        running = false; thread?.join(500); thread = null
        track?.run { try { stop() } catch (_: Exception) {}; release() }; track = null
    }
}
