package com.blacktp.app.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "tracks", indices = [Index(value = ["uri"], unique = true)])
data class TrackEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String, val title: String, val artist: String, val album: String,
    val durationMs: Long, val artPath: String?, val addedAt: Long,
    val lastPlayedAt: Long = 0, val favorite: Boolean = false
)

@Entity(tableName = "playlists")
data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(
    tableName = "playlist_tracks", primaryKeys = ["playlistId", "trackId"],
    foreignKeys = [
        ForeignKey(PlaylistEntity::class, ["id"], ["playlistId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(TrackEntity::class, ["id"], ["trackId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("trackId")]
)
data class PlaylistTrack(val playlistId: Long, val trackId: Long, val position: Int)

@Dao
interface TrackDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(t: TrackEntity): Long
    @Query("SELECT * FROM tracks ORDER BY title COLLATE NOCASE") fun all(): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks ORDER BY title COLLATE NOCASE") suspend fun allOnce(): List<TrackEntity>
    @Query("SELECT * FROM tracks WHERE favorite=1 ORDER BY title COLLATE NOCASE") fun favorites(): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE lastPlayedAt>0 ORDER BY lastPlayedAt DESC LIMIT 100") fun recentlyPlayed(): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks ORDER BY addedAt DESC LIMIT 100") fun recentlyAdded(): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE title LIKE '%'||:q||'%' OR artist LIKE '%'||:q||'%' ORDER BY title COLLATE NOCASE") fun search(q: String): Flow<List<TrackEntity>>
    @Query("UPDATE tracks SET favorite=:f WHERE id=:id") suspend fun setFavorite(id: Long, f: Boolean)
    @Query("UPDATE tracks SET lastPlayedAt=:t WHERE id=:id") suspend fun markPlayed(id: Long, t: Long)
    @Query("DELETE FROM tracks WHERE id=:id") suspend fun delete(id: Long)

    @Insert suspend fun insertPlaylist(p: PlaylistEntity): Long
    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE") fun playlists(): Flow<List<PlaylistEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addToPlaylist(pt: PlaylistTrack)
    @Query("SELECT t.* FROM tracks t JOIN playlist_tracks p ON p.trackId=t.id WHERE p.playlistId=:pid ORDER BY p.position") fun playlistTracks(pid: Long): Flow<List<TrackEntity>>
    @Query("SELECT COUNT(*) FROM playlist_tracks WHERE playlistId=:pid") suspend fun playlistSize(pid: Long): Int
    @Query("DELETE FROM playlists WHERE id=:id") suspend fun deletePlaylist(id: Long)
    @Query("DELETE FROM playlist_tracks WHERE playlistId=:pid AND trackId=:tid") suspend fun removeFromPlaylist(pid: Long, tid: Long)
}

@Database(entities = [TrackEntity::class, PlaylistEntity::class, PlaylistTrack::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun tracks(): TrackDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "blacktp.db").build().also { inst = it }
        }
    }
}

val Context.dataStore by preferencesDataStore("settings")

object Prefs {
    val LAST_ID = longPreferencesKey("last_id")
    val LAST_POS = longPreferencesKey("last_pos")
    val SHUFFLE = booleanPreferencesKey("shuffle")
    val REPEAT = intPreferencesKey("repeat")
    val VINYL = booleanPreferencesKey("vinyl")
    val INERTIA = floatPreferencesKey("inertia")
    val SENS = floatPreferencesKey("sensitivity")
    val HAPTIC = booleanPreferencesKey("haptic")
    val ANIM = booleanPreferencesKey("anim")
    val THEME = stringPreferencesKey("theme")
    val THEMES = stringPreferencesKey("themes")
    val EQ_ON = booleanPreferencesKey("eq_on")
    val EQ_LEVELS = stringPreferencesKey("eq_levels")
}
