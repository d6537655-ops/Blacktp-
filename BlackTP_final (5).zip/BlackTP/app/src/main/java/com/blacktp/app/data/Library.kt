package com.blacktp.app.data

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object Library {
    /** Imports files chosen in the system picker. Returns number of newly added tracks. */
    suspend fun import(ctx: Context, uris: List<Uri>): Int = withContext(Dispatchers.IO) {
        val dao = AppDb.get(ctx).tracks()
        val artDir = File(ctx.filesDir, "art").apply { mkdirs() }
        var added = 0
        for (u in uris) {
            try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, u)
                fun m(k: Int) = r.extractMetadata(k)?.takeIf { it.isNotBlank() }
                val art = r.embeddedPicture?.let { bytes ->
                    File(artDir, "${u.toString().hashCode()}.jpg").also { it.writeBytes(bytes) }.path
                }
                val t = TrackEntity(
                    uri = u.toString(),
                    title = m(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: fileName(ctx, u),
                    artist = m(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "Unknown artist",
                    album = m(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "Unknown album",
                    durationMs = m(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0,
                    artPath = art, addedAt = System.currentTimeMillis()
                )
                if (dao.insert(t) > 0) added++
            } catch (_: Exception) { /* unreadable / not audio: skip */ }
            finally { try { r.release() } catch (_: Exception) {} }
        }
        added
    }

    private fun fileName(ctx: Context, u: Uri): String =
        ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0)?.substringBeforeLast('.') else null
        } ?: "Track"
}
