package com.blacktp.app.player

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import androidx.datastore.preferences.core.edit
import com.blacktp.app.audio.*
import com.blacktp.app.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlin.random.Random

data class PlayerState(
    val track: TrackEntity? = null, val playing: Boolean = false, val loading: Boolean = false,
    val queue: List<TrackEntity> = emptyList(), val index: Int = -1,
    val shuffle: Boolean = false, val repeat: Int = 0, val error: String? = null
)

/** Process-wide player: owns the ScratchEngine, queue and state. UI and PlayerService both talk to it. */
object PlayerController {
    private lateinit var app: Context
    lateinit var db: AppDb; private set
    val engine = ScratchEngine()
    @Volatile var sensitivity = 1f
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()
    private var loadJob: Job? = null
    private var wantPlay = false
    private var initialized = false

    fun init(ctx: Context) {
        if (initialized) return
        initialized = true
        app = ctx.applicationContext
        db = AppDb.get(app)
        engine.onEnded = { scope.launch { onTrackEnded() } }
        engine.sessionId = app.getSystemService(AudioManager::class.java).generateAudioSessionId()
        Eq.attach(engine.sessionId)
        scope.launch {
            app.dataStore.data.collect { p ->
                engine.inertia = p[Prefs.INERTIA] ?: 0.5f
                sensitivity = p[Prefs.SENS] ?: 1f
                engine.vinylMode = p[Prefs.VINYL] ?: true
                Eq.apply(p[Prefs.EQ_ON] ?: false, Eq.parse(p[Prefs.EQ_LEVELS]))
            }
        }
        scope.launch { while (true) { delay(5000); if (_state.value.playing) savePosition() } }
        scope.launch { restore() }
    }

    private suspend fun restore() {
        val p = app.dataStore.data.first()
        val id = p[Prefs.LAST_ID] ?: return
        val all = db.tracks().allOnce()
        val i = all.indexOfFirst { it.id == id }
        if (i < 0) return
        _state.update { it.copy(shuffle = p[Prefs.SHUFFLE] ?: false, repeat = p[Prefs.REPEAT] ?: 0) }
        play(all, i, p[Prefs.LAST_POS] ?: 0L, autoplay = false)
    }

    fun play(queue: List<TrackEntity>, index: Int, startMs: Long = 0, autoplay: Boolean = true) {
        val t = queue.getOrNull(index) ?: return
        loadJob?.cancel()
        engine.playing = false
        wantPlay = autoplay
        _state.update { it.copy(track = t, queue = queue, index = index, loading = true, playing = false, error = null) }
        if (autoplay) ensureService()
        loadJob = scope.launch {
            try {
                withContext(Dispatchers.Default) {
                    val pcm = PcmDecoder.decode(app, Uri.parse(t.uri))
                    engine.load(pcm)
                    if (startMs > 0) engine.seekMs(startMs)
                }
                engine.playing = wantPlay
                _state.update { it.copy(loading = false, playing = wantPlay) }
                db.tracks().markPlayed(t.id, System.currentTimeMillis())
                savePosition()
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, playing = false, error = "Can't play: ${t.title}") }
            }
        }
    }

    fun resume() {
        val s = _state.value
        if (s.track == null) return
        wantPlay = true
        if (s.loading) return
        if (engine.pcm == null) return
        if (engine.positionMs >= engine.durationMs - 150) engine.seekMs(0)
        engine.playing = true
        ensureService()
        _state.update { it.copy(playing = true) }
    }

    fun pause() {
        wantPlay = false
        engine.playing = false
        _state.update { it.copy(playing = false) }
        savePosition()
    }

    fun toggle() { if (_state.value.playing || (_state.value.loading && wantPlay)) pause() else resume() }

    fun next(auto: Boolean = false) {
        val s = _state.value
        val i = nextIndex(auto) ?: run { pause(); engine.seekMs(0); return }
        play(s.queue, i)
    }

    fun prev() {
        val s = _state.value
        if (engine.positionMs > 3000 || s.index <= 0) { engine.seekMs(0); return }
        play(s.queue, s.index - 1)
    }

    private fun nextIndex(auto: Boolean): Int? {
        val s = _state.value; val n = s.queue.size
        if (n == 0) return null
        if (s.shuffle && n > 1) return generateSequence { Random.nextInt(n) }.first { it != s.index }
        val i = s.index + 1
        return if (i < n) i else if (s.repeat == 1 || !auto) 0 else null
    }

    private fun onTrackEnded() {
        if (_state.value.repeat == 2) { engine.seekMs(0); engine.playing = true; return }
        next(auto = true)
    }

    fun toggleShuffle() {
        val v = !_state.value.shuffle
        _state.update { it.copy(shuffle = v) }
        scope.launch { app.dataStore.edit { it[Prefs.SHUFFLE] = v } }
    }

    fun cycleRepeat() {
        val v = (_state.value.repeat + 1) % 3
        _state.update { it.copy(repeat = v) }
        scope.launch { app.dataStore.edit { it[Prefs.REPEAT] = v } }
    }

    fun toggleFavorite(t: TrackEntity) {
        val fav = !t.favorite
        scope.launch { db.tracks().setFavorite(t.id, fav) }
        _state.update { s -> s.copy(
            track = s.track?.let { if (it.id == t.id) it.copy(favorite = fav) else it },
            queue = s.queue.map { if (it.id == t.id) it.copy(favorite = fav) else it }) }
    }

    // ---- queue ----
    fun playIndex(i: Int) = play(_state.value.queue, i)
    fun moveQueue(from: Int, to: Int) {
        val s = _state.value
        if (from !in s.queue.indices || to !in s.queue.indices) return
        val q = s.queue.toMutableList(); q.add(to, q.removeAt(from))
        _state.update { it.copy(queue = q, index = q.indexOfFirst { x -> x.id == s.track?.id }) }
    }
    fun removeFromQueue(i: Int) {
        val s = _state.value
        if (i !in s.queue.indices || i == s.index) return
        val q = s.queue.toMutableList(); q.removeAt(i)
        _state.update { it.copy(queue = q, index = if (i < s.index) s.index - 1 else s.index) }
    }
    fun playNext(t: TrackEntity) {
        val s = _state.value
        if (s.track == null) { play(listOf(t), 0); return }
        val q = s.queue.toMutableList(); q.add(s.index + 1, t); _state.update { it.copy(queue = q) }
    }
    fun enqueue(t: TrackEntity) {
        val s = _state.value
        if (s.track == null) { play(listOf(t), 0); return }
        _state.update { it.copy(queue = s.queue + t) }
    }

    // ---- sleep timer (fades out over the last 10 s) ----
    private val _sleepLeft = MutableStateFlow(0L)
    val sleepLeftMs: StateFlow<Long> = _sleepLeft.asStateFlow()
    private var sleepJob: Job? = null
    fun setSleep(minutes: Int) {
        sleepJob?.cancel(); engine.gain = 1f
        if (minutes <= 0) { _sleepLeft.value = 0; return }
        sleepJob = scope.launch {
            var left = minutes * 60_000L
            while (left > 0) {
                _sleepLeft.value = left
                engine.gain = if (left < 10_000) left / 10_000f else 1f
                delay(250); left -= 250
            }
            _sleepLeft.value = 0; pause(); engine.gain = 1f
        }
    }

    fun savePosition() {
        val t = _state.value.track ?: return
        val pos = engine.positionMs
        scope.launch { app.dataStore.edit { it[Prefs.LAST_ID] = t.id; it[Prefs.LAST_POS] = pos } }
    }

    private fun ensureService() { app.startForegroundService(Intent(app, PlayerService::class.java)) }
}
