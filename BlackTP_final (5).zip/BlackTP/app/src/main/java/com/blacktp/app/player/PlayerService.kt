package com.blacktp.app.player

import android.app.*
import android.content.*
import android.graphics.BitmapFactory
import android.graphics.drawable.Icon
import android.media.*
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import com.blacktp.app.MainActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect

/** Foreground service: MediaSession + MediaStyle notification + audio focus + headphone-unplug handling. */
class PlayerService : Service() {
    private lateinit var session: MediaSession
    private lateinit var nm: NotificationManager
    private lateinit var am: AudioManager
    private var focus: AudioFocusRequest? = null
    private var hasFocus = false
    private var resumeOnGain = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { PlayerController.pause() }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        PlayerController.init(this)
        nm = getSystemService(NotificationManager::class.java)
        am = getSystemService(AudioManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Playback", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "BlackTP").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() = PlayerController.resume()
                override fun onPause() = PlayerController.pause()
                override fun onSkipToNext() = PlayerController.next()
                override fun onSkipToPrevious() = PlayerController.prev()
                override fun onSeekTo(pos: Long) = PlayerController.engine.seekMs(pos)
                override fun onStop() { PlayerController.pause() }
            })
            isActive = true
        }
        registerReceiver(noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
        val n = notification(PlayerController.state.value)
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(ID, n)
        scope.launch { PlayerController.state.collect { update(it) } }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            A_TOGGLE -> PlayerController.toggle()
            A_NEXT -> PlayerController.next()
            A_PREV -> PlayerController.prev()
        }
        return START_NOT_STICKY
    }

    private fun update(s: PlayerState) {
        val t = s.track
        if (t != null) {
            session.setMetadata(MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, t.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, t.artist)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, t.album)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, PlayerController.engine.durationMs)
                .apply { art(t.artPath)?.let { putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it) } }
                .build())
        }
        val st = when { s.playing -> PlaybackState.STATE_PLAYING; s.loading -> PlaybackState.STATE_BUFFERING; else -> PlaybackState.STATE_PAUSED }
        session.setPlaybackState(PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO)
            .setState(st, PlayerController.engine.positionMs, if (s.playing) 1f else 0f).build())
        val n = notification(s)
        if (s.playing || s.loading) {
            requestFocus()
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(ID, n)
        } else {
            stopForeground(STOP_FOREGROUND_DETACH)   // keep notification, allow swipe-away
            nm.notify(ID, n)
        }
    }

    private fun requestFocus() {
        if (hasFocus) return
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setOnAudioFocusChangeListener { c ->
                when (c) {
                    AudioManager.AUDIOFOCUS_LOSS -> { hasFocus = false; resumeOnGain = false; PlayerController.pause() }
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                        if (PlayerController.state.value.playing) { resumeOnGain = true; PlayerController.pause() }
                    }
                    AudioManager.AUDIOFOCUS_GAIN -> { if (resumeOnGain) { resumeOnGain = false; PlayerController.resume() } }
                }
            }.build()
        focus = req
        hasFocus = am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun art(path: String?) = path?.let {
        BitmapFactory.decodeFile(it, BitmapFactory.Options().apply { inSampleSize = 2 })
    }

    private fun act(a: String, icon: Int, label: String): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(this, icon), label,
            PendingIntent.getService(this, a.hashCode(), Intent(this, PlayerService::class.java).setAction(a),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)).build()

    private fun notification(s: PlayerState): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(s.track?.title ?: "BLACK TP")
            .setContentText(s.track?.artist ?: "")
            .setLargeIcon(art(s.track?.artPath))
            .setContentIntent(open)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .addAction(act(A_PREV, android.R.drawable.ic_media_previous, "Prev"))
            .addAction(act(A_TOGGLE, if (s.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause"))
            .addAction(act(A_NEXT, android.R.drawable.ic_media_next, "Next"))
            .setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2))
            .build()
    }

    override fun onTaskRemoved(i: Intent?) { if (!PlayerController.state.value.playing) stopSelf() }

    override fun onDestroy() {
        PlayerController.savePosition()
        scope.cancel()
        try { unregisterReceiver(noisy) } catch (_: Exception) {}
        focus?.let { am.abandonAudioFocusRequest(it) }
        session.release()
        super.onDestroy()
    }

    companion object {
        const val CH = "playback"; const val ID = 1
        const val A_TOGGLE = "blacktp.TOGGLE"; const val A_NEXT = "blacktp.NEXT"; const val A_PREV = "blacktp.PREV"
    }
}
