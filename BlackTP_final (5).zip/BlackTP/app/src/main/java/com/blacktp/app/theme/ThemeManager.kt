package com.blacktp.app.theme

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.datastore.preferences.core.edit
import com.blacktp.app.data.Prefs
import com.blacktp.app.data.dataStore
import com.blacktp.app.ui.Skin
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max

data class WallCfg(
    val path: String? = null, val dim: Float = 0.4f, val blur: Float = 0f,
    val scale: Float = 1f, val ox: Float = 0f, val oy: Float = 0f, val tile: Boolean = false
)

/** Colors are ARGB ints. wheel/plate/ticks are derived from `wheel`. */
data class Theme(
    val name: String, val bg: Int, val panel: Int, val wheel: Int, val accent: Int, val text: Int,
    val button: Int, val progress: Int, val lcdBg: Int, val lcdFg: Int,
    val bright: Float = 1f, val sat: Float = 1f, val amoled: Boolean = false, val uiAlpha: Float = 1f,
    val font: String = "MONO", val fontRev: Int = 0, val lcdSize: Int = 18, val cover: String = "SQUARE",
    val wpPlayer: WallCfg = WallCfg(), val wpLib: WallCfg = WallCfg()
)

private fun WallCfg.json() = JSONObject().apply {
    path?.let { put("path", it) }
    put("dim", dim.toDouble()); put("blur", blur.toDouble()); put("scale", scale.toDouble())
    put("ox", ox.toDouble()); put("oy", oy.toDouble()); put("tile", tile)
}
private fun wallFrom(o: JSONObject?) = if (o == null) WallCfg() else WallCfg(
    if (o.has("path")) o.getString("path") else null, o.optDouble("dim", 0.4).toFloat(), o.optDouble("blur", 0.0).toFloat(),
    o.optDouble("scale", 1.0).toFloat(), o.optDouble("ox", 0.0).toFloat(), o.optDouble("oy", 0.0).toFloat(), o.optBoolean("tile", false))

fun Theme.toJson() = JSONObject().apply {
    put("name", name); put("bg", bg); put("panel", panel); put("wheel", wheel); put("accent", accent); put("text", text)
    put("button", button); put("progress", progress); put("lcdBg", lcdBg); put("lcdFg", lcdFg)
    put("bright", bright.toDouble()); put("sat", sat.toDouble()); put("amoled", amoled); put("uiAlpha", uiAlpha.toDouble())
    put("font", font); put("fontRev", fontRev); put("lcdSize", lcdSize); put("cover", cover)
    put("wpPlayer", wpPlayer.json()); put("wpLib", wpLib.json())
}

fun themeFromJson(o: JSONObject): Theme {
    val d = Presets.BLACK
    return Theme(o.optString("name", "CUSTOM"), o.optInt("bg", d.bg), o.optInt("panel", d.panel), o.optInt("wheel", d.wheel),
        o.optInt("accent", d.accent), o.optInt("text", d.text), o.optInt("button", d.button), o.optInt("progress", d.progress),
        o.optInt("lcdBg", d.lcdBg), o.optInt("lcdFg", d.lcdFg), o.optDouble("bright", 1.0).toFloat(), o.optDouble("sat", 1.0).toFloat(),
        o.optBoolean("amoled", false), o.optDouble("uiAlpha", 1.0).toFloat(), o.optString("font", "MONO"), o.optInt("fontRev", 0),
        o.optInt("lcdSize", 18), o.optString("cover", "SQUARE"), wallFrom(o.optJSONObject("wpPlayer")), wallFrom(o.optJSONObject("wpLib")))
}

object Presets {
    private fun c(rgb: Long) = (0xFF000000L or rgb).toInt()
    private fun t(n: String, bg: Long, panel: Long, wheel: Long, accent: Long, text: Long, button: Long, lcdBg: Long, lcdFg: Long, font: String = "MONO") =
        Theme(n, c(bg), c(panel), c(wheel), c(accent), c(text), c(button), c(accent), c(lcdBg), c(lcdFg), font = font)

    val BLACK = t("BLACK ORIGINAL", 0x000000, 0x111111, 0x2B2B2D, 0xFF6A00, 0xE6E6E6, 0x232325, 0x0B0F0A, 0xFF8A2A)
    val WALKMAN = t("OLD WALKMAN", 0x1B1D22, 0x2A2D34, 0x8E9299, 0xFFB300, 0xE8E4D8, 0x3A3E46, 0x1A1408, 0xFFB300, "SANS")
    val IPOD = t("IPOD CLASSIC", 0xD9DADC, 0xE9EAEC, 0xF2F2F2, 0x2F7BFF, 0x1C1C1E, 0xD0D1D4, 0xC9D6C0, 0x1C2A1C, "SANS")
    val LCD = t("VINTAGE LCD", 0x10140C, 0x1A2014, 0x3A4030, 0x8FBF3F, 0xB7C79A, 0x252B1C, 0x9DAE7E, 0x1B2412)
    val INDUSTRIAL = t("INDUSTRIAL", 0x2A2C2E, 0x3A3D40, 0x6A6F75, 0xFFC400, 0xDADDE0, 0x4A4E52, 0x15171A, 0xFFC400)
    val BROTHER = t("OLDER BROTHER", 0x1A0F10, 0x2A1719, 0x4A3A34, 0xD08A4E, 0xE9DCC9, 0x36211F, 0x120A0B, 0xD9A066, "SERIF")
    val ALL = listOf(BLACK, WALKMAN, IPOD, LCD, INDUSTRIAL, BROTHER)

    /** name, bg, panel */
    val BACKGROUNDS = listOf(
        Triple("BLACK", 0x000000, 0x111111), Triple("GRAPHITE", 0x2B2D31, 0x3A3D42), Triple("SILVER", 0xC0C3C8, 0xD5D8DC),
        Triple("WHITE", 0xF4F4F4, 0xFFFFFF), Triple("NAVY", 0x0B1426, 0x14213D), Triple("BURGUNDY", 0x2A0D14, 0x3D1520),
        Triple("FOREST", 0x0E1F17, 0x17342A), Triple("PLUM", 0x1D1230, 0x2C1B47))
}

object ThemeManager {
    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _theme = MutableStateFlow(Presets.BLACK)
    val theme: StateFlow<Theme> = _theme.asStateFlow()
    private val _saved = MutableStateFlow<List<Theme>>(emptyList())
    val saved: StateFlow<List<Theme>> = _saved.asStateFlow()
    private var customFam: FontFamily? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        val p = runBlocking { app.dataStore.data.first() }   // tiny file; avoids a flash of the default theme
        p[Prefs.THEME]?.let { runCatching { themeFromJson(JSONObject(it)) }.getOrNull() }?.let { _theme.value = it }
        p[Prefs.THEMES]?.let { s -> runCatching {
            val a = JSONArray(s); _saved.value = (0 until a.length()).map { themeFromJson(a.getJSONObject(it)) }
        } }
    }

    fun update(f: (Theme) -> Theme) { _theme.value = f(_theme.value); persist() }

    /** Presets replace colors/font but keep the user's wallpapers. */
    fun applyPreset(p: Theme) = update { p.copy(wpPlayer = it.wpPlayer, wpLib = it.wpLib, bright = 1f, sat = 1f, amoled = false) }
    fun setCustom() = update { it.copy(name = "CUSTOM") }
    fun load(t: Theme) { _theme.value = t; persist() }
    fun saveAs(name: String) {
        val t = _theme.value.copy(name = name)
        _theme.value = t
        _saved.value = _saved.value.filter { it.name != name } + t; persist()
    }
    fun delete(name: String) { _saved.value = _saved.value.filter { it.name != name }; persist() }

    private fun persist() {
        val t = _theme.value.toJson().toString()
        val l = JSONArray().also { a -> _saved.value.forEach { a.put(it.toJson()) } }.toString()
        scope.launch { app.dataStore.edit { it[Prefs.THEME] = t; it[Prefs.THEMES] = l } }
    }

    fun importFont(uri: Uri): Boolean = try {
        val f = File(app.filesDir, "custom_font")
        app.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        Typeface.createFromFile(f)           // throws if it is not a font
        FontFamily(Font(f)); customFam = null; true
    } catch (_: Exception) { File(app.filesDir, "custom_font").delete(); false }

    private fun fontFor(name: String): FontFamily = when (name) {
        "SANS" -> FontFamily.SansSerif; "SERIF" -> FontFamily.Serif; "CURSIVE" -> FontFamily.Cursive; "DEFAULT" -> FontFamily.Default
        "CUSTOM" -> customFam ?: runCatching { FontFamily(Font(File(app.filesDir, "custom_font"))) }.getOrNull().also { customFam = it } ?: FontFamily.Monospace
        else -> FontFamily.Monospace
    }

    fun skin(t: Theme): Skin {
        fun adj(argb: Int): Color {
            val hsv = FloatArray(3); android.graphics.Color.colorToHSV(argb, hsv)
            hsv[1] = (hsv[1] * t.sat).coerceIn(0f, 1f); hsv[2] = (hsv[2] * t.bright).coerceIn(0f, 1f)
            return Color(android.graphics.Color.HSVToColor(hsv))
        }
        val bg = if (t.amoled) Color.Black else adj(t.bg)
        val panel = (if (t.amoled) Color(0xFF0A0A0A) else adj(t.panel)).copy(alpha = t.uiAlpha)
        val w = Color(t.wheel); val light = w.luminance() > 0.55f
        val text = Color(t.text)
        return Skin(
            bg = bg, panel = panel, wheel = w,
            wheelHi = if (light) Color.White else lerp(w, Color.White, 0.35f),
            wheelLo = lerp(w, Color.Black, if (light) 0.2f else 0.55f),
            plate = lerp(w, Color.Black, if (light) 0.08f else 0.7f),
            tick = if (light) lerp(w, Color.Black, 0.45f) else lerp(w, Color.White, 0.55f),
            accent = Color(t.accent), text = text, textDim = text.copy(alpha = 0.55f),
            lcdBg = Color(t.lcdBg), lcdFg = Color(t.lcdFg), button = Color(t.button).copy(alpha = t.uiAlpha), progress = Color(t.progress),
            font = fontFor(t.font), lcdSize = t.lcdSize, cover = t.cover, amoled = t.amoled,
            bright = t.bright, sat = t.sat, wpPlayer = t.wpPlayer, wpLib = t.wpLib)
    }
}

object WallStore {
    /** Copies the picked image into app storage (downscaled) so it survives permission loss. */
    fun save(ctx: Context, uri: Uri): String? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > 2400) s *= 2
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        }
        if (bmp == null) null else {
            val f = File(ctx.filesDir, "wp_${System.currentTimeMillis()}.jpg")
            f.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
            f.path
        }
    } catch (_: Exception) { null }
}
