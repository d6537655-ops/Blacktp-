package com.blacktp.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.blacktp.app.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun Head(t: String, skin: Skin) =
    Text(t, color = skin.accent, fontFamily = skin.font, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))

@Composable
private fun Labeled(skin: Skin, label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Text("$label  %.2f".format(value), color = skin.textDim, fontFamily = skin.font)
    Slider(value.coerceIn(range), onChange, valueRange = range)
}

@Composable
private fun SwitchRow(skin: Skin, label: String, v: Boolean, onChange: (Boolean) -> Unit) =
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = skin.text, fontFamily = skin.font); Switch(v, onChange)
    }

@Composable
private fun ColorRow(skin: Skin, label: String, argb: Int, onChange: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().clickable { open = !open }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(28.dp).background(Color(argb), RoundedCornerShape(6.dp)).border(1.dp, skin.textDim, RoundedCornerShape(6.dp)))
            Text(label, Modifier.padding(start = 12.dp).weight(1f), color = skin.text, fontFamily = skin.font)
            Text("#%06X".format(argb and 0xFFFFFF), color = skin.textDim, fontFamily = skin.font)
        }
        if (open) {
            var hex by remember(argb) { mutableStateOf("%06X".format(argb and 0xFFFFFF)) }
            OutlinedTextField(hex, { v ->
                hex = v.uppercase().filter { it in "0123456789ABCDEF" }.take(6)
                if (hex.length == 6) onChange((0xFF000000L or hex.toLong(16)).toInt())
            }, singleLine = true, label = { Text("HEX") })
            val r = (argb shr 16) and 255; val g = (argb shr 8) and 255; val b = argb and 255
            fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            Text("R $r", color = skin.textDim, fontFamily = skin.font)
            Slider(r.toFloat(), { onChange(rgb(it.toInt(), g, b)) }, valueRange = 0f..255f)
            Text("G $g", color = skin.textDim, fontFamily = skin.font)
            Slider(g.toFloat(), { onChange(rgb(r, it.toInt(), b)) }, valueRange = 0f..255f)
            Text("B $b", color = skin.textDim, fontFamily = skin.font)
            Slider(b.toFloat(), { onChange(rgb(r, g, it.toInt())) }, valueRange = 0f..255f)
        }
    }
}

@Composable
fun CustomizeScreen() {
    val ctx = LocalContext.current
    val skin = LocalSkin.current
    val scope = rememberCoroutineScope()
    val theme by ThemeManager.theme.collectAsState()
    val saved by ThemeManager.saved.collectAsState()
    var slotPlayer by remember { mutableStateOf(true) }
    var saveName by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    fun ed(f: (Theme) -> Theme) = ThemeManager.update(f)
    fun setWall(f: (WallCfg) -> WallCfg) = ed { if (slotPlayer) it.copy(wpPlayer = f(it.wpPlayer)) else it.copy(wpLib = f(it.wpLib)) }
    val cfg = if (slotPlayer) theme.wpPlayer else theme.wpLib

    val wallPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val p = withContext(Dispatchers.IO) { WallStore.save(ctx, uri) }
            if (p != null) setWall { it.copy(path = p) } else msg = "Can't read this image"
        }
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { ThemeManager.importFont(uri) }
            if (ok) ed { it.copy(font = "CUSTOM", fontRev = it.fontRev + 1) } else msg = "Not a valid .ttf/.otf font"
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("CUSTOM STUDIO  [${theme.name}]", color = skin.text, fontFamily = skin.font)
        if (msg.isNotEmpty()) Text(msg, color = skin.accent, fontFamily = skin.font)

        Head("PRESETS", skin)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Presets.ALL.forEach { p -> DevBtn(skin, p.name, theme.name == p.name) { ThemeManager.applyPreset(p) } }
            DevBtn(skin, "CUSTOM", theme.name == "CUSTOM") { ThemeManager.setCustom() }
        }

        Head("MY THEMES", skin)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(saveName, { saveName = it }, Modifier.weight(1f), singleLine = true, label = { Text("NAME") })
            DevBtn(skin, "SAVE", modifier = Modifier.padding(start = 8.dp)) { if (saveName.isNotBlank()) { ThemeManager.saveAs(saveName.trim()); saveName = "" } }
        }
        saved.forEach { t ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t.name, Modifier.weight(1f), color = if (t.name == theme.name) skin.accent else skin.text, fontFamily = skin.font)
                TextButton({ ThemeManager.load(t) }) { Text("LOAD") }
                TextButton({ ThemeManager.delete(t.name) }) { Text("DEL") }
            }
        }

        Head("BACKGROUND", skin)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Presets.BACKGROUNDS.forEach { (n, bg, pn) ->
                DevBtn(skin, n) {
                    val bgC = Color((0xFF000000L or bg.toLong()).toInt())
                    ed { t ->
                        val tc = Color(t.text)
                        val text = if (bgC.luminance() > 0.5f && tc.luminance() > 0.5f) 0xFF1C1C1E.toInt()
                        else if (bgC.luminance() <= 0.5f && tc.luminance() <= 0.5f) 0xFFE6E6E6.toInt() else t.text
                        t.copy(name = "CUSTOM", bg = (0xFF000000L or bg.toLong()).toInt(),
                            panel = (0xFF000000L or pn.toLong()).toInt(), text = text)
                    }
                }
            }
        }
        ColorRow(skin, "BACKGROUND COLOR", theme.bg) { c -> ed { it.copy(name = "CUSTOM", bg = c) } }
        ColorRow(skin, "PANEL COLOR", theme.panel) { c -> ed { it.copy(name = "CUSTOM", panel = c) } }
        Labeled(skin, "BRIGHTNESS", theme.bright, 0.2f..1.5f) { v -> ed { it.copy(bright = v) } }
        Labeled(skin, "SATURATION", theme.sat, 0f..2f) { v -> ed { it.copy(sat = v) } }
        Labeled(skin, "UI OPACITY", theme.uiAlpha, 0.2f..1f) { v -> ed { it.copy(uiAlpha = v) } }
        SwitchRow(skin, "AMOLED BLACK", theme.amoled) { v -> ed { it.copy(amoled = v) } }

        Head("WALLPAPER / TEXTURE", skin)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DevBtn(skin, "PLAYER", slotPlayer) { slotPlayer = true }
            DevBtn(skin, "LIBRARY", !slotPlayer) { slotPlayer = false }
        }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DevBtn(skin, "PICK PHOTO") { wallPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
            DevBtn(skin, "CLEAR") { setWall { it.copy(path = null) } }
        }
        Text(if (cfg.path != null) "IMAGE SET" else "NO IMAGE", color = skin.textDim, fontFamily = skin.font)
        SwitchRow(skin, "TILE AS TEXTURE", cfg.tile) { v -> setWall { it.copy(tile = v) } }
        Labeled(skin, "DIM", cfg.dim, 0f..0.9f) { v -> setWall { it.copy(dim = v) } }
        Labeled(skin, "BLUR", cfg.blur, 0f..20f) { v -> setWall { it.copy(blur = v) } }
        Labeled(skin, "SCALE", cfg.scale, 1f..3f) { v -> setWall { it.copy(scale = v) } }
        if (!cfg.tile) {
            Labeled(skin, "POSITION X", cfg.ox, -1f..1f) { v -> setWall { it.copy(ox = v) } }
            Labeled(skin, "POSITION Y", cfg.oy, -1f..1f) { v -> setWall { it.copy(oy = v) } }
        }

        Head("COLORS", skin)
        ColorRow(skin, "WHEEL", theme.wheel) { c -> ed { it.copy(name = "CUSTOM", wheel = c) } }
        ColorRow(skin, "INDICATORS", theme.accent) { c -> ed { it.copy(name = "CUSTOM", accent = c) } }
        ColorRow(skin, "TEXT", theme.text) { c -> ed { it.copy(name = "CUSTOM", text = c) } }
        ColorRow(skin, "BUTTONS", theme.button) { c -> ed { it.copy(name = "CUSTOM", button = c) } }
        ColorRow(skin, "PROGRESS BAR", theme.progress) { c -> ed { it.copy(name = "CUSTOM", progress = c) } }
        ColorRow(skin, "DISPLAY BACKGROUND", theme.lcdBg) { c -> ed { it.copy(name = "CUSTOM", lcdBg = c) } }
        ColorRow(skin, "DISPLAY TEXT", theme.lcdFg) { c -> ed { it.copy(name = "CUSTOM", lcdFg = c) } }

        Head("FONT", skin)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("MONO", "SANS", "SERIF", "CURSIVE", "DEFAULT").forEach { f -> DevBtn(skin, f, theme.font == f) { ed { it.copy(font = f) } } }
            DevBtn(skin, "IMPORT .TTF", theme.font == "CUSTOM") { fontPicker.launch(arrayOf("*/*")) }
        }

        Head("DISPLAY", skin)
        Labeled(skin, "DISPLAY SIZE", theme.lcdSize.toFloat(), 12f..28f) { v -> ed { it.copy(lcdSize = v.toInt()) } }
        Text("COVER STYLE", color = skin.textDim, fontFamily = skin.font)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("SQUARE", "ROUND", "HIDDEN").forEach { c -> DevBtn(skin, c, theme.cover == c) { ed { it.copy(cover = c) } } }
        }
        Spacer(Modifier.height(24.dp))
    }
}
