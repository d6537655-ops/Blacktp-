package com.blacktp.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.blacktp.app.data.*
import com.blacktp.app.player.PlayerController
import kotlinx.coroutines.launch

private val TABS = listOf("ALL", "ALBUMS", "ARTISTS", "FAV", "PLAYED", "ADDED", "LISTS")

@Composable
fun LibraryScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { PlayerController.db.tracks() }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var group by remember { mutableStateOf<String?>(null) }
    var openPl by remember { mutableStateOf<PlaylistEntity?>(null) }
    var newPl by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("") }
    val all by dao.all().collectAsState(emptyList())
    val playlists by dao.playlists().collectAsState(emptyList())
    val tracks by remember(tab, query, openPl) {
        when {
            query.isNotBlank() -> dao.search(query.trim())
            openPl != null -> dao.playlistTracks(openPl!!.id)
            tab == 3 -> dao.favorites(); tab == 4 -> dao.recentlyPlayed(); tab == 5 -> dao.recentlyAdded()
            else -> dao.all()
        }
    }.collectAsState(emptyList())
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) scope.launch { info = "Imported ${Library.import(ctx, uris)} / ${uris.size}" }
    }
    val skin = LocalSkin.current
    val mono = skin.font

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("SEARCH") })
            Button({ picker.launch(arrayOf("audio/*")) }, Modifier.padding(start = 8.dp)) { Text("IMPORT") }
        }
        if (info.isNotEmpty()) Text(info, color = skin.accent, fontFamily = mono, modifier = Modifier.padding(horizontal = 12.dp))
        ScrollableTabRow(tab, edgePadding = 0.dp, containerColor = Color.Transparent) {
            TABS.forEachIndexed { i, t -> Tab(tab == i, { tab = i; group = null; openPl = null }, text = { Text(t, fontFamily = mono) }) }
        }
        val isGrouping = query.isBlank() && openPl == null && (tab == 1 || tab == 2) && group == null
        val isLists = query.isBlank() && openPl == null && tab == 6
        when {
            isGrouping -> {
                val names = all.map { if (tab == 1) it.album else it.artist }.distinct().sortedBy { it.lowercase() }
                LazyColumn { itemsIndexed(names) { _, n ->
                    Text(n, Modifier.fillMaxWidth().clickable { group = n }.padding(14.dp), fontFamily = mono)
                } }
            }
            isLists -> Column {
                TextButton({ newPl = true }) { Text("+ NEW PLAYLIST", fontFamily = mono) }
                LazyColumn { itemsIndexed(playlists) { _, p ->
                    Row(Modifier.fillMaxWidth().clickable { openPl = p }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(p.name, Modifier.weight(1f), fontFamily = mono)
                        TextButton({ scope.launch { dao.deletePlaylist(p.id) } }) { Text("DEL") }
                    }
                } }
            }
            else -> {
                val shown = if (group != null && query.isBlank())
                    all.filter { (if (tab == 1) it.album else it.artist) == group } else tracks
                if (group != null || openPl != null)
                    TextButton({ group = null; openPl = null }) { Text("< BACK  ${group ?: openPl?.name}", fontFamily = mono) }
                LazyColumn { itemsIndexed(shown, key = { _, t -> t.id }) { i, t ->
                    TrackRow(t, playlists, openPl?.id,
                        onPlay = { PlayerController.play(shown, i) })
                } }
            }
        }
    }
    if (newPl) {
        var name by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { newPl = false },
            confirmButton = { TextButton({ if (name.isNotBlank()) scope.launch { dao.insertPlaylist(PlaylistEntity(name = name.trim())) }; newPl = false }) { Text("CREATE") } },
            title = { Text("New playlist") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) })
    }
}

@Composable
private fun TrackRow(t: TrackEntity, playlists: List<PlaylistEntity>, inPlaylist: Long?, onPlay: () -> Unit) {
    val scope = rememberCoroutineScope()
    val skin = LocalSkin.current
    val dao = PlayerController.db.tracks()
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().clickable(onClick = onPlay).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(t.title, fontFamily = skin.font, maxLines = 1)
            Text("${t.artist} • ${t.album}", color = skin.textDim, maxLines = 1, style = MaterialTheme.typography.bodySmall)
        }
        TextButton({ PlayerController.toggleFavorite(t) }) { Text(if (t.favorite) "♥" else "♡", color = skin.accent) }
        Box {
            TextButton({ menu = true }) { Text("⋮") }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Play next") }, onClick = { menu = false; PlayerController.playNext(t) })
                DropdownMenuItem(text = { Text("Add to queue") }, onClick = { menu = false; PlayerController.enqueue(t) })
                playlists.forEach { p ->
                    DropdownMenuItem(text = { Text("+ ${p.name}") }, onClick = {
                        menu = false
                        scope.launch { dao.addToPlaylist(PlaylistTrack(p.id, t.id, dao.playlistSize(p.id))) }
                    })
                }
                if (inPlaylist != null) DropdownMenuItem(text = { Text("Remove from playlist") },
                    onClick = { menu = false; scope.launch { dao.removeFromPlaylist(inPlaylist, t.id) } })
                DropdownMenuItem(text = { Text("Remove from library") }, onClick = { menu = false; scope.launch { dao.delete(t.id) } })
            }
        }
    }
}
