package com.blacktp.app.ui

import android.graphics.BitmapFactory
import android.media.AudioManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import com.blacktp.app.data.*
import com.blacktp.app.player.PlayerController
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

@Composable
fun PlayerScreen() {
    val ctx = LocalContext.current
    val skin = LocalSkin.current
    val scope = rememberCoroutineScope()
    val st by PlayerController.state.collectAsState()
    val engine = PlayerController.engine
    val vinyl by remember { ctx.dataStore.data.map { it[Prefs.VINYL] ?: true } }.collectAsState(true)
    val haptic by remember { ctx.dataStore.data.map { it[Prefs.HAPTIC] ?: true } }.collectAsState(true)
    val anim by remember { ctx.dataStore.data.map { it[Prefs.ANIM] ?: true } }.collectAsState(true)
    var pos by remember { mutableLongStateOf(0) }
    var dur by remember { mutableLongStateOf(0) }
    val am = remember { ctx.getSystemService(AudioManager::class.java) }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    val art = remember(st.track?.artPath) {
        st.track?.artPath?.let { BitmapFactory.decodeFile(it, BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap() }
    }
    LaunchedEffect(Unit) { while (true) { pos = engine.positionMs; dur = engine.durationMs; delay(100) } }

    Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (art != null && skin.cover != "HIDDEN") Image(art, null, Modifier.padding(end = 8.dp).size(72.dp).clip(if (skin.cover == "ROUND") CircleShape else RectangleShape))
            Lcd(skin, st.track?.title ?: "NO TRACK",
                "${st.track?.artist ?: "-"} / ${st.track?.album ?: "-"}",
                st.error ?: if (st.loading) "LOADING..." else "${fmt(pos)} / ${fmt(dur)}  ${if (vinyl) "VINYL" else "NORMAL"}",
                Modifier.weight(1f))
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Wheel(skin, st.playing, haptic, anim, { PlayerController.toggle() }, Modifier.fillMaxHeight().widthIn(max = 380.dp))
        }
        Slider(pos.toFloat(), { engine.seekMs(it.toLong()) }, valueRange = 0f..maxOf(dur, 1).toFloat(),
            colors = SliderDefaults.colors(thumbColor = skin.progress, activeTrackColor = skin.progress))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            DevBtn(skin, "SHUF", st.shuffle) { PlayerController.toggleShuffle() }
            DevBtn(skin, "|<") { PlayerController.prev() }
            DevBtn(skin, if (st.playing) "PAUSE" else "PLAY", st.playing) { PlayerController.toggle() }
            DevBtn(skin, ">|") { PlayerController.next() }
            DevBtn(skin, listOf("REP", "ALL", "ONE")[st.repeat], st.repeat != 0) { PlayerController.cycleRepeat() }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DevBtn(skin, if (vinyl) "VINYL" else "NORMAL", vinyl) { scope.launch { ctx.dataStore.edit { it[Prefs.VINYL] = !vinyl } } }
            DevBtn(skin, if (st.track?.favorite == true) "♥" else "♡", st.track?.favorite == true) { st.track?.let { PlayerController.toggleFavorite(it) } }
            Slider(vol, { vol = it; am.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0) }, Modifier.weight(1f),
                valueRange = 0f..am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat(),
                colors = SliderDefaults.colors(thumbColor = skin.progress, activeTrackColor = skin.progress))
        }
    }
}
