package com.blacktp.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.blacktp.app.player.PlayerController

@Composable
fun QueueScreen() {
    val skin = LocalSkin.current
    val st by PlayerController.state.collectAsState()
    val mono = skin.font
    if (st.queue.isEmpty()) {
        Text("QUEUE EMPTY — play something from LIBRARY", color = skin.textDim, fontFamily = mono, modifier = Modifier.padding(16.dp))
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(st.queue) { i, t ->
            val cur = i == st.index
            Row(Modifier.fillMaxWidth().clickable { PlayerController.playIndex(i) }.padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(if (cur) "▶" else "%02d".format(i + 1), color = if (cur) skin.accent else skin.textDim, fontFamily = mono, modifier = Modifier.width(32.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, color = if (cur) skin.accent else skin.text, fontFamily = mono, maxLines = 1)
                    Text(t.artist, color = skin.textDim, maxLines = 1, style = MaterialTheme.typography.bodySmall)
                }
                TextButton({ PlayerController.moveQueue(i, i - 1) }) { Text("▲") }
                TextButton({ PlayerController.moveQueue(i, i + 1) }) { Text("▼") }
                if (!cur) TextButton({ PlayerController.removeFromQueue(i) }) { Text("✕") }
            }
        }
    }
}
