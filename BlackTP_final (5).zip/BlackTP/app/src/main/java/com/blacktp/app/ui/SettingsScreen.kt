package com.blacktp.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import com.blacktp.app.audio.Eq
import com.blacktp.app.data.*
import com.blacktp.app.player.PlayerController
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val skin = LocalSkin.current
    val scope = rememberCoroutineScope()
    val mono = skin.font
    fun <T> pref(k: androidx.datastore.preferences.core.Preferences.Key<T>, def: T) = ctx.dataStore.data.map { it[k] ?: def }
    val inertia by remember { pref(Prefs.INERTIA, 0.5f) }.collectAsState(0.5f)
    val sens by remember { pref(Prefs.SENS, 1f) }.collectAsState(1f)
    val vinyl by remember { pref(Prefs.VINYL, true) }.collectAsState(true)
    val haptic by remember { pref(Prefs.HAPTIC, true) }.collectAsState(true)
    val anim by remember { pref(Prefs.ANIM, true) }.collectAsState(true)
    val eqOn by remember { pref(Prefs.EQ_ON, false) }.collectAsState(false)
    val eqStr by remember { pref(Prefs.EQ_LEVELS, "") }.collectAsState("")
    val sleepLeft by PlayerController.sleepLeftMs.collectAsState()
    fun <T> set(k: androidx.datastore.preferences.core.Preferences.Key<T>, v: T) { scope.launch { ctx.dataStore.edit { it[k] = v } } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Head("SCRATCH", skin)
        Row { Text("VINYL MODE", Modifier.weight(1f), color = skin.text, fontFamily = mono); Switch(vinyl, { set(Prefs.VINYL, it) }) }
        Text("SENSITIVITY %.2f".format(sens), color = skin.text, fontFamily = mono)
        Slider(sens, { set(Prefs.SENS, it) }, valueRange = 0.3f..3f)
        Text("INERTIA %.2f".format(inertia), color = skin.text, fontFamily = mono)
        Slider(inertia, { set(Prefs.INERTIA, it) }, valueRange = 0f..1f)

        Head("FEEDBACK", skin)
        Row { Text("HAPTIC", Modifier.weight(1f), color = skin.text, fontFamily = mono); Switch(haptic, { set(Prefs.HAPTIC, it) }) }
        Row { Text("ANIMATIONS", Modifier.weight(1f), color = skin.text, fontFamily = mono); Switch(anim, { set(Prefs.ANIM, it) }) }

        Head("EQUALIZER", skin)
        if (Eq.centersHz.isEmpty()) Text("Equalizer not available on this device", color = skin.textDim, fontFamily = mono)
        else {
            val levels = Eq.levelsOrFlat(eqStr)
            Row { Text("ENABLED", Modifier.weight(1f), color = skin.text, fontFamily = mono); Switch(eqOn, { set(Prefs.EQ_ON, it) }) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DevBtn(skin, "FLAT") { set(Prefs.EQ_LEVELS, List(levels.size) { 0 }.joinToString(",")) }
                DevBtn(skin, "BASS") { set(Prefs.EQ_LEVELS, List(levels.size) { if (it == 0) Eq.maxLevel * 2 / 3 else if (it == 1) Eq.maxLevel / 3 else 0 }.joinToString(",")) }
                DevBtn(skin, "TREBLE") { set(Prefs.EQ_LEVELS, List(levels.size) { if (it == levels.size - 1) Eq.maxLevel * 2 / 3 else if (it == levels.size - 2) Eq.maxLevel / 3 else 0 }.joinToString(",")) }
            }
            levels.forEachIndexed { i, l ->
                Text("${Eq.centersHz[i]} Hz  ${l / 100} dB", color = skin.textDim, fontFamily = mono)
                Slider(l.toFloat(), { v -> set(Prefs.EQ_LEVELS, levels.toMutableList().also { it[i] = v.toInt() }.joinToString(",")) },
                    valueRange = Eq.minLevel.toFloat()..Eq.maxLevel.toFloat())
            }
        }

        Head("SLEEP TIMER", skin)
        Text(if (sleepLeft > 0) "STOPS IN %d:%02d".format(sleepLeft / 60000, (sleepLeft / 1000) % 60) else "OFF", color = skin.text, fontFamily = mono)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15, 30, 60).forEach { m -> DevBtn(skin, "${m}m") { PlayerController.setSleep(m) } }
            DevBtn(skin, "OFF") { PlayerController.setSleep(0) }
        }
    }
}

@Composable
private fun Head(t: String, skin: Skin) { Text(t, color = skin.accent, fontFamily = skin.font, modifier = Modifier.padding(top = 12.dp)) }
