package com.blacktp.app.ui

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import com.blacktp.app.theme.*

/** Runtime colors/fonts derived from the user's Theme by ThemeManager.skin(). */
data class Skin(
    val bg: Color, val panel: Color,
    val wheel: Color, val wheelHi: Color, val wheelLo: Color, val plate: Color, val tick: Color,
    val accent: Color, val text: Color, val textDim: Color,
    val lcdBg: Color, val lcdFg: Color, val button: Color, val progress: Color,
    val font: FontFamily, val lcdSize: Int, val cover: String, val amoled: Boolean,
    val bright: Float, val sat: Float, val wpPlayer: WallCfg, val wpLib: WallCfg
)

val Orange = Color(0xFFFF6A00)
val LocalSkin = compositionLocalOf { ThemeManager.skin(Presets.BLACK) }
