package com.blacktp.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.blacktp.app.theme.WallCfg
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun load(path: String, blur: Float): ImageBitmap? {
    val b = BitmapFactory.decodeFile(path) ?: return null
    if (blur < 0.5f) return b.asImageBitmap()
    val f = (1 + blur).toInt().coerceAtLeast(2)   // heavy downscale + smooth upscale = blur on every API level
    return Bitmap.createScaledBitmap(b, (b.width / f).coerceAtLeast(1), (b.height / f).coerceAtLeast(1), true).asImageBitmap()
}

@Composable
fun Wallpaper(skin: Skin, cfg: WallCfg, modifier: Modifier = Modifier) {
    val bmp by produceState<ImageBitmap?>(null, cfg.path, cfg.blur) {
        value = withContext(Dispatchers.IO) { cfg.path?.let { load(it, cfg.blur) } }
    }
    Box(modifier.background(skin.bg)) {
        val img = bmp
        if (!skin.amoled && img != null) Canvas(Modifier.fillMaxSize()) {
            val m = ColorMatrix().apply { setToSaturation(skin.sat) }
            val b = skin.bright
            m *= ColorMatrix(floatArrayOf(b, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, 1f, 0f))
            if (cfg.tile) {
                scale(cfg.scale, cfg.scale, Offset.Zero) {
                    drawRect(ShaderBrush(ImageShader(img, TileMode.Repeated, TileMode.Repeated)),
                        size = Size(size.width / cfg.scale, size.height / cfg.scale))
                }
            } else {
                val w = size.width; val h = size.height
                val base = maxOf(w / img.width, h / img.height) * cfg.scale
                val dw = img.width * base; val dh = img.height * base
                val x = (w - dw) / 2f + cfg.ox * (dw - w) / 2f
                val y = (h - dh) / 2f + cfg.oy * (dh - h) / 2f
                drawImage(img, dstOffset = IntOffset(x.toInt(), y.toInt()), dstSize = IntSize(dw.toInt(), dh.toInt()),
                    colorFilter = ColorFilter.colorMatrix(m), filterQuality = FilterQuality.Medium)
            }
            drawRect(Color.Black.copy(alpha = cfg.dim))
        }
    }
}
