package com.blacktp.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import com.blacktp.app.player.PlayerController
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2

@Composable
fun Wheel(skin: Skin, playing: Boolean, haptics: Boolean, animate: Boolean, onCenterTap: () -> Unit, modifier: Modifier = Modifier) {
    val engine = PlayerController.engine
    val view = LocalView.current
    var angle by remember { mutableFloatStateOf(0f) }

    // idle spin follows the real playback rate (33 1/3 rpm = 200 deg/s)
    LaunchedEffect(animate) {
        var last = 0L
        while (true) withFrameNanos { t ->
            if (animate && last != 0L && !engine.touching) angle += engine.currentRate * 200f * (t - last) / 1e9f
            last = t
        }
    }

    Canvas(modifier.aspectRatio(1f).pointerInput(haptics) {
        awaitEachGesture {
            val down = awaitFirstDown()
            val c = Offset(size.width / 2f, size.height / 2f)
            val r = size.minDimension / 2f
            if ((down.position - c).getDistance() < r * 0.28f) {          // center button
                var moved = false
                do {
                    val ev = awaitPointerEvent(); val ch = ev.changes.first()
                    if ((ch.position - down.position).getDistance() > 24f) moved = true
                    ch.consume()
                } while (ev.changes.any { it.pressed })
                if (!moved) { if (haptics) view.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); onCenterTap() }
                return@awaitEachGesture
            }
            var prev = atan2(down.position.y - c.y, down.position.x - c.x)
            var prevT = down.uptimeMillis
            var acc = 0f
            engine.wheelRate = 0f
            engine.touching = true
            try {
                do {
                    val ev = awaitPointerEvent(); val ch = ev.changes.first()
                    val a = atan2(ch.position.y - c.y, ch.position.x - c.x)
                    var d = a - prev
                    if (d > PI) d -= (2 * PI).toFloat()
                    if (d < -PI) d += (2 * PI).toFloat()
                    val dt = (ch.uptimeMillis - prevT).coerceAtLeast(1) / 1000f
                    if (ch.uptimeMillis != prevT)
                        engine.wheelRate = (d / (2 * PI.toFloat()) / dt) / 0.5556f * PlayerController.sensitivity
                    val deg = Math.toDegrees(d.toDouble()).toFloat()
                    angle += deg
                    acc += abs(deg)
                    if (haptics && acc >= 12f) { acc = 0f; view.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK) }
                    prev = a; prevT = ch.uptimeMillis; ch.consume()
                } while (ev.changes.any { it.pressed })
            } finally { engine.touching = false }
        }
    }) {
        val r = size.minDimension / 2f
        val c = center
        // brushed-metal body: fixed sweep highlights (light does not rotate with the wheel)
        drawCircle(Color.Black, r)
        drawCircle(Brush.sweepGradient(listOf(skin.wheel, skin.wheelHi, skin.wheel, skin.wheelLo, skin.wheel, skin.wheelHi, skin.wheel, skin.wheelLo, skin.wheel), c), r * 0.97f)
        drawCircle(Brush.radialGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.45f)), c, r), r * 0.97f)
        drawCircle(skin.wheelHi.copy(alpha = 0.6f), r * 0.97f, style = Stroke(2f))
        rotate(angle, c) {
            for (i in 0 until 60) rotate(i * 6f, c) {
                val long = i % 5 == 0
                drawLine(skin.tick, Offset(c.x, c.y - r * 0.93f), Offset(c.x, c.y - r * (if (long) 0.83f else 0.88f)), if (long) 3f else 1.5f)
            }
            drawLine(skin.accent, Offset(c.x, c.y - r * 0.50f), Offset(c.x, c.y - r * 0.78f), 7f, StrokeCap.Round)
            drawCircle(skin.accent, r * 0.025f, Offset(c.x, c.y - r * 0.82f))
        }
        // inner plate + center button
        drawCircle(skin.plate, r * 0.46f)
        drawCircle(skin.wheelHi.copy(alpha = 0.4f), r * 0.46f, style = Stroke(2f))
        drawCircle(Brush.radialGradient(listOf(skin.wheel, skin.wheelLo), c, r * 0.27f), r * 0.27f)
        drawCircle(if (playing) skin.accent else skin.accent.copy(alpha = 0.25f), r * 0.28f, style = Stroke(4f))
        val s = r * 0.09f
        if (playing) {
            drawRect(skin.text, Offset(c.x - s, c.y - s), androidx.compose.ui.geometry.Size(s * 0.7f, s * 2))
            drawRect(skin.text, Offset(c.x + s * 0.3f, c.y - s), androidx.compose.ui.geometry.Size(s * 0.7f, s * 2))
        } else {
            val p = Path().apply { moveTo(c.x - s * 0.6f, c.y - s); lineTo(c.x + s, c.y); lineTo(c.x - s * 0.6f, c.y + s); close() }
            drawPath(p, skin.text)
        }
    }
}
