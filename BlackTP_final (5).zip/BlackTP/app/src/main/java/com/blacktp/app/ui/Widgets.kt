package com.blacktp.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Lcd(skin: Skin, line1: String, line2: String, line3: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(6.dp)
    Box(modifier.fillMaxWidth().clip(shape).background(skin.lcdBg).border(1.dp, Color(0xFF3A3A3A), shape)
        .drawWithContent {
            drawContent()
            var y = 0f
            while (y < size.height) { drawLine(Color.Black.copy(alpha = 0.18f), Offset(0f, y), Offset(size.width, y), 1f); y += 3f }
        }.padding(10.dp)) {
        Column {
            Text(line1, color = skin.lcdFg, fontFamily = skin.font, fontSize = skin.lcdSize.sp, maxLines = 1, modifier = Modifier.basicMarquee())
            Text(line2, color = skin.lcdFg.copy(alpha = 0.7f), fontFamily = skin.font, fontSize = (skin.lcdSize * 0.65f).sp, maxLines = 1)
            Text(line3, color = skin.lcdFg, fontFamily = skin.font, fontSize = (skin.lcdSize * 0.78f).sp, maxLines = 1)
        }
    }
}

@Composable
fun DevBtn(skin: Skin, text: String, active: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    Box(modifier.clip(shape).background(skin.button).border(1.dp, if (active) skin.accent else skin.textDim.copy(alpha = 0.35f), shape)
        .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp)) {
        Text(text, color = if (active) skin.accent else skin.text, fontFamily = skin.font, fontSize = 13.sp)
    }
}
